import {
  Page,
} from "@shopify/polaris";
import Widgets from "app/component/widgets";







export default function FeaturePage() {
  return (
    <Page>
      <Widgets />
    </Page>
  );
}
