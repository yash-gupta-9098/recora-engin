
import {
  BlockStack,
  Box,
  Button,
  Card,
  Divider,
  InlineGrid,
  InlineStack,
  Text,
} from "@shopify/polaris";

import { EditIcon } from "@shopify/polaris-icons"; 

const items = [
  {
  title: "New Arrivale",
  subText: "Shows the Newly added products from store"
}, 
{
  title: "Related Products",
  subText: "Display the related products based on various conditions like same collection, tags, vendor & type"
}, 
{
  title: "AI Based Recommendations",
  subText: "Shows the relevant products inspired by users browsing history"
}, 
{
  title: "Recently Viewed Products",
  subText: "Shows the recently viewed products which were browsed by visitor"
}, 
{
  title: "Trending Products",
  subText: "Shows products which were sold most number of times or the best sellers by A.I."
}, 
{
  title: "Featured Products",
  subText: "You can assign products to a collection and select that here to show Featured Products"
}
] 




interface WidgetProps {
  heading?: string;
} 


export default function Widgets({heading}: WidgetProps){
return(

<BlockStack gap={"400"}>

    {heading  && ( <Text as="h4" variant="headingLg">{heading}</Text>)}


    <InlineGrid gap="400" columns={3}>
        {items.map((item) => (
         
        <InlineStack>
            <div className="rec-card  Polaris-ShadowBevel" style={{display:"flex", flexDirection:"column",  height:"100%" , width:"100%" , padding:"1rem" ,  gap:"10px" , }}>
              <Text as="h2" variant="headingSm">
                {item.title}
              </Text>
              <Divider borderColor="border"/>
              <Text as="h3" variant="headingSm" fontWeight="medium">
                {item.subText}
              </Text>

              {/* This spacer pushes the button to the bottom */}
              <div style={{ flexGrow: 1 }} />

              {/* Align button to the bottom-right */}
              <InlineStack align="end">
                <Button
                  variant="secondary"
                  icon={EditIcon}
                  onClick={() => {}}
                >
                  Setup
                </Button>
              </InlineStack>
            </div>
        </InlineStack>
        ))}
      </InlineGrid>
      </BlockStack>
)

}