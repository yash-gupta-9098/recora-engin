import React from 'react'

export default function Mobile() {
  return (
    <div>Mobile</div>
  )
}
