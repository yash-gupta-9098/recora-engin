import React from 'react'

export default function Tablet() {
  return (
    <div>Tablet</div>
  )
}
