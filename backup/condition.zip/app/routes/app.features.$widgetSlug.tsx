import { json, LoaderFunction, ActionFunction } from "@remix-run/node";
import { useLoaderData, useFetcher } from "@remix-run/react";
import { Text } from "@shopify/polaris";
import WidgetSetting from "../component/Widget";
import { authenticate } from "app/shopify.server";
import { getShopSettings } from "db/getShopSettings";
import { useReducer } from "react";
import WidgetPage from "../component/Widget";

// Database types
interface WidgetRuleCondition {
  id: string;
  field: string;
  operator: string;
  value: string;
  widgetId: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}


export type RuleLogic = 'all' | 'any';

interface Condition {
  id: string;
  field: string;      // e.g. "product_title"
  operator: string;   // e.g. "contains"
  value: string;
}



interface RuleSettings {
  priceMatch: RuleLogic;
  conditions: Condition[];
} 

export type ConditionFieldKey = 'field' | 'operator' | 'value';

interface WidgetState{
  title: string;
  active: boolean;
  no_of_products: number;
  backend: {
    widgetName: string;
    widgetDescription: string;
  };
  ruleSettings: RuleSettings
  widgetsSettings: {
    heading:string;
    subHeading:string;
    viewType: string;
    layoutValue: string;
    viewCardDesign: string;
    totalProduct: number;
    rangeDeskProValue: number;
    rangeTbtProValue: number;
    rangeMbProValue: number;
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
};

export interface SetLogicAction {
  type: 'SET_LOGIC';
  payload: { widgetId: string; priceMatch: RuleLogic };
}


export interface AddConditionAction {
  type: 'ADD_CONDITION';
  payload: { widgetId: string };
}


export interface UpdateConditionAction {
  type: 'UPDATE_CONDITION';
  payload: {
    widgetId: string;
    conditionId: string;
    field: ConditionFieldKey;
    value: string;
  };
}


export interface DeleteConditionAction {
  type: 'DELETE_CONDITION';
  payload: { widgetId: string; conditionId: string };
}



// type State = Record<string, WidgetState>;

// type Action =
//   | {
//       type: "UPDATE_WIDGET";
//       payload: {
//         widgetId: string;
//         settings: Partial<WidgetState>;
//       };
//     };

// export function reducer(state: State, action: Action): State {
//   switch (action.type) {
//     case "UPDATE_WIDGET": {
//       const { widgetId, settings } = action.payload;

//       return {
//         ...state,
//         [widgetId]: {
//           ...state[widgetId],
//           ...settings,
//           ruleSettings: {
//             ...state[widgetId].ruleSettings,
//             ...(settings.ruleSettings || {}),
//             conditions: settings.ruleSettings?.conditions
//             ? [...state[widgetId].ruleSettings.conditions, ...settings.ruleSettings.conditions]
//             : state[widgetId].ruleSettings.conditions,
//           },
//           widgetsSettings: {
//             ...state[widgetId].widgetsSettings,
//             ...(settings.widgetsSettings || {}),
//           },
//         },
//       };
//     }

//     default:
//       return state;
//   }
// }



// interface staticWidgetData  {
  
// }

// Static data storage (simulates database)
// let staticWidgetData: Record<string, WidgetState> = {
//   "New Arrivals": {
//     id: "New Arrivals",
//     backend: {
//       widgetName: "New Arrivals",
//       widgetDescription: "Displays the latest products added to the store."
//     },
//     ruleSettings: {
//       priceMatch: "all",
//       conditions: [
//         {
//           id: "condition_1",
//           field: "product_title",
//           operator: "contains",
//           value: "hello",
//           widgetId: "New Arrivals",
//           order: 1,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         }, 
//         {
//           id: "condition_2",
//           field: "product_type",
//           operator: "is_equal_to",
//           value: "shirt",
//           widgetId: "New Arrivals",
//           order: 2,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         },
//         {
//           id: "condition_3",
//           field: "product_vendor",
//           operator: "is_equal_to",
//           value: "Nike",
//           widgetId: "New Arrivals",
//           order: 3,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         }
//       ]
//     },
//     widgetSettings: {
//       viewType: "grid",
//       layoutValue: "Layout_1",
//       viewCardDesign: "vertical",
//       totalProduct: 10,
//       rangeDeskProValue: 4,
//       rangeTbtProValue: 3,
//       rangeMbProValue: 2,
//       heading: "New Arrivals"
//     },
//     isActive: true,
//     createdAt: new Date().toISOString(),
//     updatedAt: new Date().toISOString()
//   },
//   "Related Products": {
//     id: "Related Products",
//     backend: {
//       widgetName: "Related Products",
//       widgetDescription: "Displays products related to the current product."
//     },
//     ruleSettings: {
//       priceMatch: "any",
//       conditions: [
//         {
//           id: "condition_2",
//           field: "product_type",
//           operator: "is_equal_to",
//           value: "",
//           widgetId: "Related Products",
//           order: 1,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         },
//         {
//           id: "condition_3",
//           field: "product_tags",
//           operator: "is_equal_to",
//           value: "",
//           widgetId: "Related Products",
//           order: 2,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         },
//         {
//           id: "condition_4",
//           field: "product_vendor",
//           operator: "is_equal_to",
//           value: "",
//           widgetId: "Related Products",
//           order: 3,
//           createdAt: new Date().toISOString(),
//           updatedAt: new Date().toISOString()
//         }
//       ]
//     },
//     widgetSettings: {
//       viewType: "slider",
//       layoutValue: "Layout_2",
//       viewCardDesign: "horizontal",
//       totalProduct: 8,
//       rangeDeskProValue: 3,
//       rangeTbtProValue: 2,
//       rangeMbProValue: 1,
//       heading: "Related Products"
//     },
//     isActive: true,
//     createdAt: new Date().toISOString(),
//     updatedAt: new Date().toISOString()
//   },
//   "AI Based Recommendation": {
//     id: "AI Based Recommendation",
//     backend: {
//       widgetName: "AI Based Recommendation",
//       widgetDescription: "Displays AI-powered product recommendations."
//     },
//     ruleSettings: {
//       priceMatch: "all",
//       conditions: []
//     },
//     widgetSettings: {
//       viewType: "grid",
//       layoutValue: "Layout_3",
//       viewCardDesign: "vertical",
//       totalProduct: 12,
//       rangeDeskProValue: 4,
//       rangeTbtProValue: 3,
//       rangeMbProValue: 2,
//       heading: "AI Based Recommendation"
//     },
//     isActive: true,
//     createdAt: new Date().toISOString(),
//     updatedAt: new Date().toISOString()
//   }
// };

// console.log("Static data initialized:", staticWidgetData);

// Simple static data functions
const staticDataService = {
  getAllWidgets: async (staticWidgetData : Record<string, WidgetState>): Promise<WidgetState[]> => {

      if (!staticWidgetData || typeof staticWidgetData !== 'object') return [];

  // Create a shallow copy so the original object isn't mutated
  const filteredData = { ...staticWidgetData };

  // Remove the HomeSettings key if it exists
  // if ('homeSettings' in filteredData) {
  //   delete filteredData['homeSettings'];
  // }else if('productSettings' in filteredData) {
  //   delete filteredData['productSettings'];
  // }
  // else if('collectionSettings' in filteredData) {
  //   delete filteredData['collectionSettings'];
  // } 
  // else if('cartSettings' in filteredData) {
  //   delete filteredData['cartSettings'];
  // } 
  // else if('otherSettings' in filteredData) {
  //   delete filteredData['otherSettings'];
  // } 


  // Return all remaining widget values
  return Object.values(filteredData);
  },

  addCondition: async (condition: Omit<WidgetRuleCondition, 'id' | 'createdAt' | 'updatedAt'> , staticWidgetData : Record<string, WidgetState>): Promise<WidgetRuleCondition> => {
    const newCondition: WidgetRuleCondition = {
      ...condition,
      id: `condition_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Update the static data
    if (staticWidgetData[condition.widgetId]) {
      staticWidgetData[condition.widgetId].ruleSettings.conditions.push(newCondition);
    }

    return newCondition;
  },

  updateCondition: async (conditionId: string, updates: Partial<WidgetRuleCondition> , staticWidgetData : Record<string, WidgetState>): Promise<WidgetRuleCondition> => {
    // Find and update the condition in static data
    for (const widget of Object.values(staticWidgetData)) {
      const conditionIndex = widget.ruleSettings.conditions.findIndex(c => c.id === conditionId);
      if (conditionIndex !== -1) {
        widget.ruleSettings.conditions[conditionIndex] = {
          ...widget.ruleSettings.conditions[conditionIndex],
          ...updates,
          updatedAt: new Date().toISOString()
        };
        return widget.ruleSettings.conditions[conditionIndex];
      }
    }
    throw new Error("Condition not found");
  },

  deleteCondition: async (conditionId: string , staticWidgetData : Record<string, WidgetState>): Promise<boolean> => {
    // Remove condition from static data
    for (const widget of Object.values(staticWidgetData)) {
      const conditionIndex = widget.ruleSettings.conditions.findIndex(c => c.id === conditionId);
      if (conditionIndex !== -1) {
        widget.ruleSettings.conditions.splice(conditionIndex, 1);
        return true;
      }
    }
    return false;
  },

  updateWidgetPriceMatch: async (widgetId: string, priceMatch: 'all' | 'any' , staticWidgetData : Record<string, WidgetState>): Promise<boolean> => {
    if (staticWidgetData[widgetId]) {
      staticWidgetData[widgetId].ruleSettings.priceMatch = priceMatch;
      staticWidgetData[widgetId].updatedAt = new Date().toISOString();
      return true;
    }
    return false;
  }



};

export const loader: LoaderFunction = async ({ params ,  request}) => {
  const { widgetSlug} = params;

  // console.log("Loader called with params:", params);
  // console.log("Page name:", widgetSlug);

  try {
    // Get all widgets for this page
    // console.log("Found widgets:", widgets);
    
    const {session} = await authenticate.admin(request);  

    const defaultSettings = await getShopSettings(session.shop)

    // console.log(defaultSettings  , "defaultSettings")
// console.log("WidgetSlug", widgetSlug)
    const staticWidgetNew = defaultSettings[widgetSlug as keyof typeof defaultSettings]
   
    // Convert to the format expected by the component
    const widgets = await staticDataService.getAllWidgets(staticWidgetNew?.widgets);
    console.log(widgets , "widgets")
    const widgetSettings: Record<string, WidgetState> = {};
    widgets.forEach(widget => {
      widgetSettings[widget.title] = widget;
    });


  
    // console.log("Final widgetSettings:", widgetSettings);
    return json({ widgetSlug, widgetSettings });
  } catch (error) {
    console.error("Error loading widget settings:", error);
    throw new Error("Failed to load widget settings");
  }
};

export const action: ActionFunction = async ({ request }) => {
  const formData = await request.formData();
  const action = formData.get("action") as string;

  try {
    switch (action) {
      case "addCondition": {
        const widgetId = formData.get("widgetId") as string;
        const field = formData.get("field") as string;
        const operator = formData.get("operator") as string;
        const value = formData.get("value") as string;
        
        // Get current conditions to determine order
        const widget = staticWidgetData[widgetId];
        const order = widget ? widget.ruleSettings.conditions.length + 1 : 1;

        const newCondition = await staticDataService.addCondition({
          field,
          operator,
          value,
          widgetId,
          order,
        });

        return json({ success: true, condition: newCondition });
      }

      case "updateCondition": {
        const conditionId = formData.get("conditionId") as string;
        const field = formData.get("field") as string;
        const operator = formData.get("operator") as string;
        const value = formData.get("value") as string;

        const updatedCondition = await staticDataService.updateCondition(conditionId, {
          field,
          operator,
          value
        });

        return json({ success: true, condition: updatedCondition });
      }

      case "deleteCondition": {
        const conditionId = formData.get("conditionId") as string;
        
        await staticDataService.deleteCondition(conditionId);

        return json({ success: true });
      }

      case "updatePriceMatch": {
        const widgetId = formData.get("widgetId") as string;
        const priceMatch = formData.get("priceMatch") as 'all' | 'any';
        
        await staticDataService.updateWidgetPriceMatch(widgetId, priceMatch);

        return json({ success: true });
      }

      default:
        return json({ success: false, error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Error in action:", error);
    return json({ success: false, error: "Internal server error" }, { status: 500 });
  }
};








export default function Widgets() {


  type WidgetAction =
  | { type: "UPDATE_WIDGET"; payload: { widgetId: string; settings: Partial<WidgetState> } }
  | { type: "SET_ALL_WIDGETS"; payload: Record<string, WidgetState> }
  | SetLogicAction
  | AddConditionAction
  | UpdateConditionAction
  | DeleteConditionAction 

function widgetReducer(
  state: Record<string, WidgetState>,
  action: WidgetAction
): Record<string, WidgetState> {
  switch (action.type) {
    case "SET_ALL_WIDGETS":
      return action.payload;

 case "UPDATE_WIDGET": {
      const { widgetId, settings } = action.payload;
      return {
        ...state,
        [widgetId]: {
          ...state[widgetId],
          ...settings,
          ruleSettings: {
            ...state[widgetId].ruleSettings,
            ...(settings.ruleSettings || {}),
            conditions: settings.ruleSettings?.conditions
            ? [...state[widgetId].ruleSettings.conditions, ...settings.ruleSettings.conditions]
            : state[widgetId].ruleSettings.conditions,
          },
          widgetsSettings: {
            ...state[widgetId].widgetsSettings,
            ...(settings.widgetsSettings || {}),
          },
        },
      };
    }
case "SET_LOGIC": {
  const { widgetId, priceMatch } = action.payload;
  const w = state[widgetId];
  return {
    ...state,
    [widgetId]: {
      ...w,
      ruleSettings: { ...w.ruleSettings, priceMatch}
    }
  };
}

case 'ADD_CONDITION': {
      const { widgetId } = action.payload;
      const w = state[widgetId];
      if (!w) return state;
      const newCond: Condition = {
        id: `cond_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
        field: 'product_title',
        operator: 'contains',
        value: '',
      };
      return {
        ...state,
        [widgetId]: {
          ...w,
          ruleSettings: {
            ...w.ruleSettings,
            conditions: [...w.ruleSettings.conditions, newCond],
          },
        },
      };
    }

case 'UPDATE_CONDITION': {
      const { widgetId, conditionId, field, value } = action.payload;
      const w = state[widgetId];
      if (!w) return state;
      const next = w.ruleSettings.conditions.map((c) =>
        c.id === conditionId ? { ...c, [field]: value } : c
      );
      return {
        ...state,
        [widgetId]: { ...w, ruleSettings: { ...w.ruleSettings, conditions: next } },
      };
    }

case 'DELETE_CONDITION': {
      const { widgetId, conditionId } = action.payload;
      const w = state[widgetId];
      if (!w) return state;
      const next = w.ruleSettings.conditions.filter((c) => c.id !== conditionId);
      return {
        ...state,
        [widgetId]: { ...w, ruleSettings: { ...w.ruleSettings, conditions: next } },
      };
    }
    
    default:
      return state;
  }
}


 

const customDispatch = (action: WidgetAction) => {
  dispatch(action);
  // shopify.saveBar.show('global-settings')

};

  
  const { widgetSlug, widgetSettings } = useLoaderData<typeof loader>();


  console.log(widgetSettings , "new ")
  const [UpdatedPageSetting , dispatch] = useReducer(widgetReducer, widgetSettings);


  console.log(UpdatedPageSetting,  "UpdatedPageSetting")
  // const fetcher = useFetcher();

  // console.log("Main component - widgetSlug:", widgetSlug);
  // console.log("Main component - widgetSettings:", widgetSettings);

  const handleSettingsChange = (widgetId: string, settings: any) => {
    // console.log("Settings changed for widget:", widgetId, settings);
    // Here you would typically save the settings to your database
    // For now, we'll just log the changes
  };

  return (
    <>
      <WidgetPage 
        pageName={widgetSlug} 
        settings={UpdatedPageSetting} 
        // onSettingsChange={handleSettingsChange}
        
        dispatch={customDispatch}
        // fetcher={fetcher}
      />
    </>
  );
}