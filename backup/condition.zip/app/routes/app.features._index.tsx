import { Page } from "@shopify/polaris";
import Widgets from "app/component/Widgets";

export default function Index() {
  return (
    <Page>
      <Widgets />
    </Page>
  );
} 