import { Outlet } from "@remix-run/react";

export default function Widget() {
    return (    
    <>
    <Outlet/>    
    </>
  )
}           