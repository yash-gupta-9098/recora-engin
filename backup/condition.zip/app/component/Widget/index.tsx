import React from "react";
import { TitleBar } from "@shopify/app-bridge-react";
import { ActionList, BlockStack, Box, Button, Card, Collapsible, FormLayout, InlineGrid, InlineStack, Key, Layout, Link, Page, Popover, RadioButton, Select, Text, TextContainer, TextField } from "@shopify/polaris";
import { useCallback, useState, useEffect } from "react";
import { DeleteIcon, ExternalIcon, LayoutPopupIcon, PlusIcon, XIcon } from '@shopify/polaris-icons';
import WidgetRuleCondition from "./WidgetRuleCondition";
import WidgetSettings from "./widgetSettings";
// import type { FetcherWithComponents } from "@remix-run/react";

// Simple fetcher interface for now
interface FetcherWithComponents<T = any> {
  data: T | null;
  state: 'idle' | 'submitting' | 'loading';
  formData: FormData | null;
  submit: (formData: FormData, options?: { method: string }) => void;
}

interface WidgetRuleConditionData {
  id: string;
  field: string;
  operator: string;
  value: string;
  widgetId?: string;
  order?: number;
  createdAt?: string;
  updatedAt?: string;
}

interface WidgetState {
  id: string;
  slug?: string;
  backend: {
    widgetName: string;
    widgetDescription: string;
  };
  ruleSettings: {
    priceMatch: 'all' | 'any';
    conditions: WidgetRuleConditionData[];
  };
  widgetsSettings?: {
    viewType: string;
    layoutValue: string;
    viewCardDesign: string;
    totalProduct: number;
    rangeDeskProValue: number;
    rangeTbtProValue: number;
    rangeMbProValue: number;
  };
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

interface WidgetSettingProps {
  pageName: string;
  settings: Record<string, WidgetState>;
  dispatch: React.Dispatch<any>;
  // fetcher?: FetcherWithComponents<any>;
  // onSettingsChange?: (widgetId: string, settings: any) => void;
}

export default function WidgetPage({ pageName, settings, dispatch }: WidgetSettingProps) {

console.log(settings  , "widgetSettings"

)
  const [openWidget, setOpenWidget] = useState<string | null>(Object.keys(settings)[0]);
  console.log(openWidget , "openWidget")
  const [showSlidekick, setShowSlidekick] = useState(false)

  // Update local state when fetcher data changes
  // useEffect(() => {
  //   if (fetcher?.data && fetcher.data.success) {
  //     // Handle different action responses
  //     if (fetcher.data.condition) {
  //       // Update the specific condition in the widget
  //       setWidgetStates(prev => {
  //         const updated = { ...prev };
  //         Object.keys(updated).forEach(widgetKey => {
  //           const widget = updated[widgetKey];
  //           const conditionIndex = widget.ruleSettings.conditions.findIndex(
  //             c => c.id === fetcher.data.condition.id
  //           );

  //           if (conditionIndex !== -1) {
  //             // Update existing condition
  //             widget.ruleSettings.conditions[conditionIndex] = fetcher.data.condition;
  //           } else if (fetcher.formData?.get('action') === 'addCondition') {
  //             // Add new condition
  //             widget.ruleSettings.conditions.push(fetcher.data.condition);
  //           }
  //         });
  //         return updated;
  //       });
  //     }
  //   }
  // }, [fetcher?.data]);

  // Close settings panel when no widget is open
  // useEffect(() => {
  //   if (openWidget === null && showSlidekick) {
  //     setShowSlidekick(false);
  //   }
  // }, []);

  const handleToggle = useCallback((key: string) => {
    setOpenWidget((prev) => {
      const newValue = prev === key ? null : key;

      // If no widget is open, close the settings panel
      if (newValue === null) {
        setShowSlidekick(false);
      }

      return newValue;
    });
  }, []);

  const handlePriceMatchChange = useCallback((widgetKey: string, newValue: 'all' | 'any') => {
    // Update local state immediately for UI responsiveness
    dispatch({
  type: 'SET_LOGIC',
  payload: { widgetId: widgetKey, priceMatch : newValue},
})

    // Send to database
    // if (fetcher) {
    //   const formData = new FormData();
    //   formData.append('action', 'updatePriceMatch');
    //   formData.append('widgetId', key);
    //   formData.append('priceMatch', newValue);
    //   fetcher.submit(formData, { method: 'post' });
    // }
  }, []);

  const handleAddCondition = useCallback((widgetKey: string) => {
    const newCondition: WidgetRuleConditionData = {
      id: `temp_${Date.now()}`, // Temporary ID for optimistic update
      field: 'product_title',
      operator: 'contains',
      value: '',
      widgetId: widgetKey
    };

    // Optimistic update
    dispatch({
      type: "ADD_CONDITION",
      payload: { widgetId: widgetKey },
    });



    // Send to database
    // if (fetcher) {
    //   const formData = new FormData();
    //   formData.append('action', 'addCondition');
    //   formData.append('widgetId', widgetKey);
    //   formData.append('field', newCondition.field);
    //   formData.append('operator', newCondition.operator);
    //   formData.append('value', newCondition.value);
    //   fetcher.submit(formData, { method: 'post' });
    // }
  }, []);

  const handleRemoveCondition = useCallback((widgetKey: string, conditionId: string) => {
    // Optimistic update
   dispatch( {
  type: 'DELETE_CONDITION',
  payload: { widgetId : widgetKey, conditionId },
})
  

    
  }, []);

  const handleConditionChange = useCallback((widgetKey: string, conditionId: string, field: 'field' | 'operator' | 'value', value: string) => {
    // Optimistic update
   dispatch({
  type: 'UPDATE_CONDITION',
  payload: { widgetId : widgetKey, conditionId, field, value },
});

    // Send to database
    
  }, []);


  function capitalize(text: string): string {
    if (!text) return '';
    return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
  }

  const capitalizedPageName = capitalize(pageName);

  console.log("Capitalized Page Name:", capitalizedPageName);

  const settingKick = {
    md: "5fr 2fr",
  }








  return (
    <>
      <TitleBar
        title={`${capitalizedPageName} Page`}
      />
{/* {console.log(widgetStates , "retun")} */}
      <Page title={`${capitalizedPageName} Page`} backAction={{ content: 'Back', onAction: () => { } }} >
        <InlineGrid columns={showSlidekick ? settingKick : 1} gap="200">
          <BlockStack gap={"500"}>
            {Object.entries(settings as Record<string, WidgetState>).map(([key, widget]) => (
              <Card key={key}>
                <BlockStack gap="400">
                  <InlineStack align="space-between" blockAlign="center" gap="200">
                    <div>
                      <Text as="h2" variant="headingMd" fontWeight="bold">
                        {widget.backend.widgetName} 
                      </Text>
                      <Text as="p" variant="bodyMd">
                        {widget.backend.widgetDescription}
                      </Text>
                    </div>
                    <div>
                      <InlineStack align="end" gap="200">
                        <Button
                          onClick={() => handleToggle(key)}
                          ariaExpanded={openWidget === key}
                          ariaControls={`collapsible-${key}`}>
                          Customize
                        </Button>
                        <Button
                          url={`#`}
                          variant="primary"
                          icon={ExternalIcon}
                        >
                          {`Add Widget`}
                        </Button>
                      </InlineStack>
                    </div>
                  </InlineStack>
                  <Collapsible
                    open={openWidget === key}
                    id={`collapsible-${key}`}
                    transition={{ duration: "500ms", timingFunction: "ease-in-out" }}
                    expandOnPrint
                  >

                    <InlineGrid columns={showSlidekick ? 1 : settingKick} gap="400">


                    
                      <Card>
                        <BlockStack gap="200">
                          <Text as="h3" fontWeight="bold">Condition</Text>
                          {widget.ruleSettings.conditions.length > 0 ? (
                          <InlineStack blockAlign="center" gap="500">
                            <Text as="p" variant="bodyMd">
                              Products must match:
                            </Text>
                            <div>
                              <InlineStack gap="500">
                                <RadioButton
                                  label="all conditions"
                                  checked={widget.ruleSettings.priceMatch === 'all'}
                                  id={`all-${key}`}
                                  name={`matchWidgetsAllRule-${key}`}
                                  onChange={() => handlePriceMatchChange(key, 'all')}
                                />
                                <RadioButton
                                  label="any condition"
                                  id={`any-${key}`}
                                  name={`matchWidgetsAllRule-${key}`}
                                  checked={widget.ruleSettings.priceMatch === 'any'}
                                  onChange={() => handlePriceMatchChange(key, 'any')}
                                />
                              </InlineStack>
                            </div>
                          </InlineStack>
                          ):
                          <Text as="p" >You can Add multiple conditions as per your preference to customize which products are displayed in this section.</Text>
                          
                          }

                          {widget.ruleSettings.conditions.map((condition) => (
                            <WidgetRuleCondition
                              key={condition.id}
                              condition={{
                                id: condition.id,
                                field: condition.field,
                                operator: condition.operator,
                                value: condition.value
                              }}   
                              onRemove={() => handleRemoveCondition(key, condition.id)}
                              onChange={(field, value) => handleConditionChange(key, condition.id, field, value)}
                            />
                          ))} 

                          <InlineStack>
                            <Button
                              icon={PlusIcon}
                              onClick={() => handleAddCondition(key)}
                              // loading={fetcher?.state === 'submitting'}
                            >
                              {`Add ${(widget.ruleSettings.conditions.length > 0) ? "Another" : ''} Condition `}
                            </Button>
                          </InlineStack>
                        </BlockStack>
                      </Card>
                  
                      {!showSlidekick &&
                        <Box
                          as="section"
                        >
                          <BlockStack gap="400">
                            <Text as="h3" variant="headingMd">
                              InterJambs
                            </Text>
                            <Text as="p" variant="bodyMd">
                              Interjambs are the rounded protruding bits of your puzzlie piece
                            </Text>
                            <InlineStack>
                              <Button onClick={() => { setShowSlidekick((prev: boolean) => !prev) }}>Customize Settings</Button>
                            </InlineStack>
                          </BlockStack>
                        </Box>}
                    </InlineGrid>

                  </Collapsible>
                </BlockStack>
              </Card>
            ))}
          </BlockStack>


            

          {showSlidekick && openWidget && (
            <WidgetSettings
              setShowSlidekick={setShowSlidekick}
              widgetName={settings[openWidget]?.backend.widgetName || "Widget"}
              widgetsSettings={settings[openWidget]?.widgetsSettings}
              widgetKey={openWidget  || '' }
              dispatch={dispatch}
              // onSettingsChange={(settings) => {
              //   if (openWidget && onSettingsChange) {
              //     onSettingsChange(openWidget, settings);
              //   }
              // }}
            />
          )}

        </InlineGrid>
      </Page>
    </>
  )
}


// // utils/format.ts
// export function capitalize(text: string): string {
//   if (!text) return '';
//   return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
// }