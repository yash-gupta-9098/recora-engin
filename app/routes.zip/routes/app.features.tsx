import { Outlet } from "@remix-run/react";
import {
  Page,
} from "@shopify/polaris";
// import Widgets from "app/component/Widgets";








export default function FeaturePage() {
  return (
      <Outlet />
  );
}
