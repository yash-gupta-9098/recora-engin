import { json, LoaderFunction, ActionFunction } from "@remix-run/node";
import { useLoaderData, useFetcher } from "@remix-run/react";
import { Text } from "@shopify/polaris";
import WidgetSetting from "../component/Widget";

// Database types
interface WidgetRuleCondition {
  id: string;
  field: string;
  operator: string;
  value: string;
  widgetId: string;
  order: number;
  createdAt: string;
  updatedAt: string;
}

interface WidgetState {
  id: string;
  backend: {
    widgetName: string;
    widgetDescription: string;
  };
  ruleSettings: {
    priceMatch: 'all' | 'any';
    conditions: WidgetRuleCondition[];
  };
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

// Static data storage (simulates database)
let staticWidgetData: Record<string, WidgetState> = {
  "New Arrivals": {
    id: "New Arrivals",
    backend: {
      widgetName: "New Arrivals",
      widgetDescription: "Displays the latest products added to the store."
    },
    ruleSettings: {
      priceMatch: "all",
      conditions: [
        {
          id: "condition_1",
          field: "product_title",
          operator: "contains",
          value: "hello",
          widgetId: "New Arrivals",
          order: 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }, 
        {
          id: "condition_2",
          field: "product_type",
          operator: "is_equal_to",
          value: "shirt",
          widgetId: "New Arrivals",
          order: 2,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: "condition_3",
          field: "product_vendor",
          operator: "is_equal_to",
          value: "Nike",
          widgetId: "New Arrivals",
          order: 3,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ]
    },
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  "Related Products": {
    id: "Related Products",
    backend: {
      widgetName: "Related Products",
      widgetDescription: "Displays products related to the current product."
    },
    ruleSettings: {
      priceMatch: "any",
      conditions: [
        {
          id: "condition_2",
          field: "product_type",
          operator: "is_equal_to",
          value: "",
          widgetId: "Related Products",
          order: 1,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: "condition_3",
          field: "product_tags",
          operator: "is_equal_to",
          value: "",
          widgetId: "Related Products",
          order: 2,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: "condition_4",
          field: "product_vendor",
          operator: "is_equal_to",
          value: "",
          widgetId: "Related Products",
          order: 3,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ]
    },
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  "AI Based Recommendation": {
    id: "AI Based Recommendation",
    backend: {
      widgetName: "AI Based Recommendation",
      widgetDescription: "Displays AI-powered product recommendations."
    },
    ruleSettings: {
      priceMatch: "all",
      conditions: []
    },
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
};

console.log("Static data initialized:", staticWidgetData);

// Simple static data functions
const staticDataService = {
  getAllWidgets: async (): Promise<WidgetState[]> => {
    return Object.values(staticWidgetData);
  },

  addCondition: async (condition: Omit<WidgetRuleCondition, 'id' | 'createdAt' | 'updatedAt'>): Promise<WidgetRuleCondition> => {
    const newCondition: WidgetRuleCondition = {
      ...condition,
      id: `condition_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    // Update the static data
    if (staticWidgetData[condition.widgetId]) {
      staticWidgetData[condition.widgetId].ruleSettings.conditions.push(newCondition);
    }

    return newCondition;
  },

  updateCondition: async (conditionId: string, updates: Partial<WidgetRuleCondition>): Promise<WidgetRuleCondition> => {
    // Find and update the condition in static data
    for (const widget of Object.values(staticWidgetData)) {
      const conditionIndex = widget.ruleSettings.conditions.findIndex(c => c.id === conditionId);
      if (conditionIndex !== -1) {
        widget.ruleSettings.conditions[conditionIndex] = {
          ...widget.ruleSettings.conditions[conditionIndex],
          ...updates,
          updatedAt: new Date().toISOString()
        };
        return widget.ruleSettings.conditions[conditionIndex];
      }
    }
    throw new Error("Condition not found");
  },

  deleteCondition: async (conditionId: string): Promise<boolean> => {
    // Remove condition from static data
    for (const widget of Object.values(staticWidgetData)) {
      const conditionIndex = widget.ruleSettings.conditions.findIndex(c => c.id === conditionId);
      if (conditionIndex !== -1) {
        widget.ruleSettings.conditions.splice(conditionIndex, 1);
        return true;
      }
    }
    return false;
  },

  updateWidgetPriceMatch: async (widgetId: string, priceMatch: 'all' | 'any'): Promise<boolean> => {
    if (staticWidgetData[widgetId]) {
      staticWidgetData[widgetId].ruleSettings.priceMatch = priceMatch;
      staticWidgetData[widgetId].updatedAt = new Date().toISOString();
      return true;
    }
    return false;
  }
};

export const loader: LoaderFunction = async ({ params }) => {
  const { widgetSlug } = params;

  console.log("Loader called with params:", params);
  console.log("Page name:", widgetSlug);

  try {
    // Get all widgets for this page
    const widgets = await staticDataService.getAllWidgets();
    console.log("Found widgets:", widgets);

    // Convert to the format expected by the component
    const widgetSettings: Record<string, WidgetState> = {};
    widgets.forEach(widget => {
      widgetSettings[widget.id] = widget;
    });

    console.log("Final widgetSettings:", widgetSettings);
    return json({ widgetSlug, widgetSettings });
  } catch (error) {
    console.error("Error loading widget settings:", error);
    throw new Error("Failed to load widget settings");
  }
};

export const action: ActionFunction = async ({ request }) => {
  const formData = await request.formData();
  const action = formData.get("action") as string;

  try {
    switch (action) {
      case "addCondition": {
        const widgetId = formData.get("widgetId") as string;
        const field = formData.get("field") as string;
        const operator = formData.get("operator") as string;
        const value = formData.get("value") as string;
        
        // Get current conditions to determine order
        const widget = staticWidgetData[widgetId];
        const order = widget ? widget.ruleSettings.conditions.length + 1 : 1;

        const newCondition = await staticDataService.addCondition({
          field,
          operator,
          value,
          widgetId,
          order
        });

        return json({ success: true, condition: newCondition });
      }

      case "updateCondition": {
        const conditionId = formData.get("conditionId") as string;
        const field = formData.get("field") as string;
        const operator = formData.get("operator") as string;
        const value = formData.get("value") as string;

        const updatedCondition = await staticDataService.updateCondition(conditionId, {
          field,
          operator,
          value
        });

        return json({ success: true, condition: updatedCondition });
      }

      case "deleteCondition": {
        const conditionId = formData.get("conditionId") as string;
        
        await staticDataService.deleteCondition(conditionId);

        return json({ success: true });
      }

      case "updatePriceMatch": {
        const widgetId = formData.get("widgetId") as string;
        const priceMatch = formData.get("priceMatch") as 'all' | 'any';
        
        await staticDataService.updateWidgetPriceMatch(widgetId, priceMatch);

        return json({ success: true });
      }

      default:
        return json({ success: false, error: "Invalid action" }, { status: 400 });
    }
  } catch (error) {
    console.error("Error in action:", error);
    return json({ success: false, error: "Internal server error" }, { status: 500 });
  }
};

export default function Widgets() {
  const { widgetSlug, widgetSettings } = useLoaderData<typeof loader>();
  const fetcher = useFetcher();

  console.log("Main component - widgetSlug:", widgetSlug);
  console.log("Main component - widgetSettings:", widgetSettings);

  return (
    <>
      <WidgetSetting 
        pageName={widgetSlug} 
        settings={widgetSettings} 
        // fetcher={fetcher}
      />
    </>
  );
}