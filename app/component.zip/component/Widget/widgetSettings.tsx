import { ActionList, BlockStack, Box, Button, ButtonGroup, Card, Divider, Icon, InlineGrid, InlineStack, Popover, RangeSlider, Text, TextField, Tooltip } from "@shopify/polaris";
import { useCallback, useState } from "react";
import { DeleteIcon, ExternalIcon, LayoutBuyButtonHorizontalIcon, LayoutBuyButtonVerticalIcon, LayoutPopupIcon, PlusIcon, XIcon } from '@shopify/polaris-icons';
export default function WidgetSettings({ setShowSlidekick }: { setShowSlidekick: (show: boolean) => void }) {

    // view 
    const [viewType, setViewType] = useState("grid");
    const handleViewType = useCallback(
        (value: string) => {
            setViewType(value)
        },
        [],
    );


    // layout
    const [layoutValue, setLayoutValue] = useState("Layout_1");
    const [popoverActive, setPopoverActive] = useState(false);
    const togglePopoverActive = useCallback(
        () => setPopoverActive((popoverActive) => !popoverActive),
        [],
    );

    // card design
    const [viewCardDesign, setViewCardDesign] = useState("vertical");


    const handleViewCardDesign = useCallback(
        (value: string) => {
            setViewCardDesign(value)
        },
        [],
    );


    // maximum product
    const [totalProduct, setTotalProduct] = useState(10);

    const handleTotalProductRange = useCallback(
        (value: number) => {
            setTotalProduct(value)
        },
        [],
    );

    // product Per Screen  
    const [rangeDeskProValue, setRrangeDeskProValue] = useState(4);
    const [rangeTbtProValue, setRrangeTbtProValue] = useState(3);
    const [rangeMbProValue, setRrangeMbProValue] = useState(2);
    const handleDeskProRange = useCallback(
        (value: number) => {
            setRrangeDeskProValue(value)
        },
        [],
    );
    const handleTbtProRange = useCallback(
        (value: number) => {

            setRrangeTbtProValue(value)
        },
        [],
    );
    const handleMbProRange = useCallback(
        (value: number) => {

            setRrangeMbProValue(value)
        },
        [],
    );



    return (
        <Card>
            <BlockStack gap={"500"}>
                <Box as="div" position="absolute" insetInlineEnd="300"><Button icon={XIcon} onClick={() => setShowSlidekick(false)}></Button></Box>
                <Text as="h2" variant="headingMd" fontWeight="bold">Home Page Settings</Text>
                <Divider borderColor="border" />
                <BlockStack gap={"300"}>

                    {/* view  */}
                    <InlineStack gap={"100"} align="space-between" blockAlign="center">
                        <Text as="p" variant="bodyMd" fontWeight="bold">View:</Text>
                        <Box background="bg-fill-secondary" borderRadius="200">
                            <ButtonGroup variant="segmented" >
                                <Button size="slim" variant={viewType === "grid" ? "secondary" : "tertiary"} onClick={() => { handleViewType("grid") }}>Grid</Button>
                                <Button size="slim" variant={viewType === "slider" ? "secondary" : "tertiary"} onClick={() => { handleViewType("slider") }}>Slider</Button>
                            </ButtonGroup>
                        </Box>
                    </InlineStack>



                    {/* Template */}
                    <InlineStack align="space-between" blockAlign="center">
                        <Text as="p" variant="bodyMd" fontWeight="bold">Template:</Text>
                        <Popover
                            active={popoverActive}
                            activator={<Button variant="secondary" disclosure="select" icon={LayoutPopupIcon} onClick={togglePopoverActive}>
                                {layoutValue}
                            </Button>}
                            autofocusTarget="none"
                            onClose={togglePopoverActive}
                        >
                            <Popover.Pane fixed>
                                <Popover.Section>
                                    <p>Select Template</p>
                                </Popover.Section>
                            </Popover.Pane>
                            <Popover.Pane>
                                <ActionList
                                    actionRole="menuitem"
                                    items={[
                                        { content: 'Layout 1', onAction: () => setLayoutValue("Layout_1") },
                                        { content: 'Layout 2', onAction: () => setLayoutValue("Layout_2") },
                                        { content: 'Layout 3', onAction: () => setLayoutValue("Layout_3") },
                                    ]}

                                />
                            </Popover.Pane>
                        </Popover>
                    </InlineStack>

                    {/*  Card-design  */}
                    <InlineStack gap={"100"} align="space-between" blockAlign="center">
                        <Text as="p" variant="bodyMd" fontWeight="bold">Card Design:</Text>
                        <Box background="bg-fill-secondary" borderRadius="200">
                            <ButtonGroup variant="segmented" >
                                <Tooltip content="Vertical Card" dismissOnMouseOut>
                                    <Button size="slim" variant={viewCardDesign === "vertical" ? "secondary" : "tertiary"} onClick={() => { handleViewCardDesign("vertical") }} icon={LayoutBuyButtonVerticalIcon}> </Button>
                                </Tooltip>
                                <Tooltip content="Horizontal Card" dismissOnMouseOut>
                                    <Button size="slim" variant={viewCardDesign === "horizontal" ? "secondary" : "tertiary"} onClick={() => { handleViewCardDesign("horizontal") }} icon={LayoutBuyButtonHorizontalIcon}> </Button>
                                </Tooltip>
                            </ButtonGroup>
                        </Box>
                    </InlineStack>


                    {/* max-Product */}
                    <InlineGrid gap={"100"}>
                        <Text as="p" variant="bodyMd" fontWeight="bold">Maximum products to show:</Text>
                        <InlineStack gap={"100"} align="space-between" blockAlign="center">
                            <RangeSlider
                                label=" "
                                min={1}
                                step={1}
                                max={20}
                                value={totalProduct}
                                onChange={handleTotalProductRange}
                                suffix={<p> <TextField labelHidden={true} autoSize={true} type="number" name="Maximum Products to show" value={totalProduct} onChange={(value) => handleTotalProductRange(Number(value))} min={1} max={20} autoComplete="off" size='slim' label /></p>}
                                output={true}
                            />
                        </InlineStack>
                    </InlineGrid>

                    {/* Product Per Screen  */}
                    {/* Desktop */}
                    <InlineGrid gap={"100"}>
                        <Box position='relative' paddingBlockStart={"500"} paddingBlockEnd={"200"} paddingInlineEnd={"300"} >
                            <Divider borderColor="border"></Divider>
                            <Box position="absolute" background="bg-surface" paddingInlineEnd={"100"} insetInlineStart={"0"} insetBlockStart={"200"} >
                                <Text as="p" variant='bodyMd' fontWeight="bold">Desktop</Text>
                            </Box>
                        </Box>

                        <Text as="p" variant="bodyMd" >Product per row</Text>
                        <InlineStack gap={"100"} align="space-between" blockAlign="center">
                            <RangeSlider
                                label=""
                                min={1}
                                step={0.1}
                                max={10}
                                value={rangeDeskProValue}
                                onChange={handleDeskProRange}
                                suffix={<p><TextField type="number" value={rangeDeskProValue} onChange={(value) => handleDeskProRange(Number(value))} min={1} max={10} maxLength={2} autoComplete="off" labelHidden={true} label /></p>}
                                output={true}
                            />

                        </InlineStack>
                    </InlineGrid>

                    {/* Tablet Per Row  */}
                    <InlineGrid gap={"100"}>
                        <Box position='relative' paddingBlockStart={"500"} paddingBlockEnd={"200"} paddingInlineEnd={"300"} >
                            <Divider></Divider>
                            <Box position="absolute" background="bg-surface" paddingInlineEnd={"100"} insetInlineStart={"0"} insetBlockStart={"200"} >
                                <Text as="p" variant='bodyMd' fontWeight="bold">Tablet Layout</Text>
                            </Box>
                        </Box>                        
                        <InlineGrid gap={"100"}>
                            <Text as="p" variant="bodyMd" >Product per row</Text>
                            <InlineStack gap={"100"} align="space-between" blockAlign="center">
                                <RangeSlider
                                    label=""
                                    min={1}
                                    step={0.1}
                                    max={6}
                                    value={rangeTbtProValue}
                                    onChange={handleTbtProRange}
                                    suffix={<p><TextField type="number" value={rangeTbtProValue} onChange={(value) =>handleTbtProRange(Number(value))} min={1} max={4} autoComplete="off" /></p>}
                                    output={true}
                                />

                            </InlineStack>
                        </InlineGrid>
                    </InlineGrid>

                    {/* Mobile Per Row  */}
                    <InlineGrid gap={"100"}>
                        <Box position='relative' paddingBlockStart={"500"} paddingBlockEnd={"200"} paddingInlineEnd={"300"} >
                            <Divider></Divider>
                            <Box position="absolute" background="bg-surface" paddingInlineEnd={"100"} insetInlineStart={"0"} insetBlockStart={"200"} >
                                <Text as="p" variant='bodyMd' fontWeight="bold">Mobile Layout</Text>
                            </Box>
                        </Box>

                        <InlineGrid gap={"100"}>
                            <Text as="p" variant="bodyMd" >Product per row</Text>
                            <InlineStack gap={"100"} align="space-between" blockAlign="center">
                                <RangeSlider
                                    label=""
                                    min={1}
                                    step={0.1}
                                    max={4}
                                    value={rangeMbProValue}
                                    onChange={handleMbProRange}
                                    suffix={<p><TextField type="number" value={rangeMbProValue} onChange={(value) => handleMbProRange(Number(value))} min={1} step={0.1} max={3} autoComplete="off" /></p>}
                                    output={true}
                                />

                            </InlineStack>
                        </InlineGrid>
                    </InlineGrid>



                </BlockStack>
            </BlockStack>
        </Card>
    );
}