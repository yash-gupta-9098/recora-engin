import React from "react";
import { TitleBar } from "@shopify/app-bridge-react";
import { ActionList, BlockStack, Box, Button, Card, Collapsible, FormLayout, InlineGrid, InlineStack, Key, Layout, Link, Page, Popover, RadioButton, Select, Text, TextContainer, TextField } from "@shopify/polaris";
import { useCallback, useState, useEffect } from "react";
import { DeleteIcon, ExternalIcon, LayoutPopupIcon, PlusIcon, XIcon } from '@shopify/polaris-icons';
import WidgetRuleCondition from "./WidgetRuleCondition";
import WidgetSettings from "./widgetSettings";
// import type { FetcherWithComponents } from "@remix-run/react";

// Simple fetcher interface for now
interface FetcherWithComponents<T = any> {
  data: T | null;
  state: 'idle' | 'submitting' | 'loading';
  formData: FormData | null;
  submit: (formData: FormData, options?: { method: string }) => void;
}

interface WidgetRuleConditionData {
  id: string;
  field: string;
  operator: string;
  value: string;
  widgetId?: string;
  order?: number;
  createdAt?: string;
  updatedAt?: string;
}

interface WidgetState {
  id: string;
  slug?: string;
  backend: {
    widgetName: string;
    widgetDescription: string;
  };
  ruleSettings: {
    priceMatch: 'all' | 'any';
    conditions: WidgetRuleConditionData[];
  };
  isActive?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

interface WidgetSettingProps {
  pageName: string;
  settings: Record<string, WidgetState>;
  fetcher?: FetcherWithComponents<any>;
}

export default function WidgetSetting({ pageName, settings, fetcher }: WidgetSettingProps) {

  console.log(settings, "settings in WidgetSetting");

  // Initialize widget states with default conditions if none exist
  const initializeWidgetStates = (settings: Record<string, WidgetState>) => {
    const initialized = { ...settings };
    Object.keys(initialized).forEach(key => {
      if (!initialized[key].ruleSettings.conditions || initialized[key].ruleSettings.conditions.length === 0) {
        initialized[key].ruleSettings.conditions = [{
          id: Date.now().toString(),
          field: 'product_title',
          operator: 'contains',
          value: ''
        }];
      }
    });
    return initialized;
  };

  const [widgetStates, setWidgetStates] = useState<Record<string, WidgetState>>(initializeWidgetStates(settings));
  const [openWidget, setOpenWidget] = useState<string | null>(Object.keys(settings)[0]);
  const [ showSlidekick ,  setShowSlidekick] = useState(false)
 
  // Update local state when fetcher data changes
  useEffect(() => {
    if (fetcher?.data && fetcher.data.success) {
      // Handle different action responses
      if (fetcher.data.condition) {
        // Update the specific condition in the widget
        setWidgetStates(prev => {
          const updated = { ...prev };
          Object.keys(updated).forEach(widgetKey => {
            const widget = updated[widgetKey];
            const conditionIndex = widget.ruleSettings.conditions.findIndex(
              c => c.id === fetcher.data.condition.id
            );
            
            if (conditionIndex !== -1) {
              // Update existing condition
              widget.ruleSettings.conditions[conditionIndex] = fetcher.data.condition;
            } else if (fetcher.formData?.get('action') === 'addCondition') {
              // Add new condition
              widget.ruleSettings.conditions.push(fetcher.data.condition);
            }
          });
          return updated;
        });
      }
    }
  }, [fetcher?.data]);

  const handleToggle = useCallback((key: string) => {
    setOpenWidget((prev) => (prev === key ? null : key));
  }, []);

  const handlePriceMatchChange = useCallback((key: string, newValue: 'all' | 'any') => {
    // Update local state immediately for UI responsiveness
    setWidgetStates((prev) => ({
      ...prev,
      [key]: {
        ...prev[key],
        ruleSettings: {
          ...prev[key].ruleSettings,
          priceMatch: newValue
        }
      }
    }));

    // Send to database
    if (fetcher) {
      const formData = new FormData();
      formData.append('action', 'updatePriceMatch');
      formData.append('widgetId', key);
      formData.append('priceMatch', newValue);
      fetcher.submit(formData, { method: 'post' });
    }
  }, [fetcher]);

  const handleAddCondition = useCallback((widgetKey: string) => {
    const newCondition: WidgetRuleConditionData = {
      id: `temp_${Date.now()}`, // Temporary ID for optimistic update
      field: 'product_title',
      operator: 'contains',
      value: '',
      widgetId: widgetKey
    };

    // Optimistic update
    setWidgetStates((prev) => ({
      ...prev,
      [widgetKey]: {
        ...prev[widgetKey],
        ruleSettings: {
          ...prev[widgetKey].ruleSettings,
          conditions: [...prev[widgetKey].ruleSettings.conditions, newCondition]
        }
      }
    }));

    // Send to database
    if (fetcher) {
      const formData = new FormData();
      formData.append('action', 'addCondition');
      formData.append('widgetId', widgetKey);
      formData.append('field', newCondition.field);
      formData.append('operator', newCondition.operator);
      formData.append('value', newCondition.value);
      fetcher.submit(formData, { method: 'post' });
    }
  }, [fetcher]);

  const handleRemoveCondition = useCallback((widgetKey: string, conditionId: string) => {
    // Optimistic update
    setWidgetStates((prev) => ({
      ...prev,
      [widgetKey]: {
        ...prev[widgetKey],
        ruleSettings: {
          ...prev[widgetKey].ruleSettings,
          conditions: prev[widgetKey].ruleSettings.conditions.filter(c => c.id !== conditionId)
        }
      }
    }));

    // Send to database
    if (fetcher) {
      const formData = new FormData();
      formData.append('action', 'deleteCondition');
      formData.append('conditionId', conditionId);
      fetcher.submit(formData, { method: 'post' });
    }
  }, [fetcher]);

  const handleConditionChange = useCallback((widgetKey: string, conditionId: string, field: 'field' | 'operator' | 'value', value: string) => {
    // Optimistic update
    setWidgetStates((prev) => ({
      ...prev,
      [widgetKey]: {
        ...prev[widgetKey],
        ruleSettings: {
          ...prev[widgetKey].ruleSettings,
          conditions: prev[widgetKey].ruleSettings.conditions.map(c => 
            c.id === conditionId ? { ...c, [field]: value } : c
          )
        }
      }
    }));

    // Send to database
    if (fetcher) {
      const formData = new FormData();
      formData.append('action', 'updateCondition');
      formData.append('conditionId', conditionId);
      formData.append('field', field === 'field' ? value : '');
      formData.append('operator', field === 'operator' ? value : '');
      formData.append('value', field === 'value' ? value : '');
      fetcher.submit(formData, { method: 'post' });
    }
  }, [fetcher]);


function capitalize(text: string): string {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
}
 
const capitalizedPageName = capitalize(pageName); 

console.log("Capitalized Page Name:", capitalizedPageName);

const settingKick = {
  md:"5fr 2fr",
}







  
  return (
    <>
      <TitleBar
        title={`${capitalizedPageName} Page`}
      />

      <Page title={`${capitalizedPageName} Page`} backAction={{ content: 'Back', onAction: () => {} }} >
        <InlineGrid columns={showSlidekick ? settingKick : 1} gap="200">
        <BlockStack gap={"500"}>
          {Object.entries(widgetStates as Record<string, WidgetState>).map(([key, widget]) => (
            <Card key={key}>
              <BlockStack gap="400">
                <InlineStack align="space-between" blockAlign="center" gap="200">
                  <div>
                    <Text as="h2" variant="headingMd" fontWeight="bold">
                      {widget.backend.widgetName}
                    </Text>
                    <Text as="p" variant="bodyMd">
                      {widget.backend.widgetDescription}
                    </Text>
                  </div>
                  <div>
                    <InlineStack align="end" gap="200">
                      <Button
                        onClick={() => handleToggle(key)}
                        ariaExpanded={openWidget === key}
                        ariaControls={`collapsible-${key}`}>
                        Customize
                      </Button>
                      <Button
                        url={`#`}
                        variant="primary"
                        icon={ExternalIcon}
                      >
                        {`Add Widget`}
                      </Button>
                    </InlineStack>
                  </div>
                </InlineStack>
                <Collapsible
                  open={openWidget === key}
                  id={`collapsible-${key}`}
                  transition={{ duration: "500ms", timingFunction: "ease-in-out" }}
                  expandOnPrint
                >
                 
                    <InlineGrid columns={showSlidekick ? 1 : settingKick} gap="400">

                  <Card>
                    <BlockStack gap="200">
                      <Text as="h3" fontWeight="bold">Condition</Text>
                      <InlineStack blockAlign="center" gap="500">
                        <Text as="p" variant="bodyMd">
                          Products must match:
                        </Text>
                        <div>
                          <InlineStack gap="500">
                            <RadioButton
                              label="all conditions"
                              checked={widget.ruleSettings.priceMatch === 'all'}
                              id={`all-${key}`}
                              name={`matchWidgetsAllRule-${key}`}
                              onChange={() => handlePriceMatchChange(key, 'all')}
                            />
                            <RadioButton
                              label="any condition"
                              id={`any-${key}`}
                              name={`matchWidgetsAllRule-${key}`}
                              checked={widget.ruleSettings.priceMatch === 'any'}
                              onChange={() => handlePriceMatchChange(key, 'any')}
                            />
                          </InlineStack>
                        </div>
                      </InlineStack>

                      {widget.ruleSettings.conditions.map((condition) => (
                        <WidgetRuleCondition
                          key={condition.id}
                          condition={{
                            id: condition.id,
                            field: condition.field,
                            operator: condition.operator,
                            value: condition.value
                          }}
                          showRemoveButton = {widget.ruleSettings.conditions.length > 1}
                          onRemove={() => handleRemoveCondition(key, condition.id)}
                          onChange={(field, value) => handleConditionChange(key, condition.id, field, value)}
                        />
                      ))}

                      <InlineStack>
                        <Button 
                        icon={PlusIcon}
                          onClick={() => handleAddCondition(key)}
                          loading={fetcher?.state === 'submitting'}
                        >
                          Add another condition
                        </Button>
                      </InlineStack>
                    </BlockStack>
                  </Card>
                 { !showSlidekick && 
                  <Box
                      as="section"
                      >
                      <BlockStack gap="400">
                      <Text as="h3" variant="headingMd">
                        InterJambs
                      </Text>
                      <Text as="p" variant="bodyMd">
                        Interjambs are the rounded protruding bits of your puzzlie piece
                      </Text>
                      <Button onClick={()=>{setShowSlidekick((prev : boolean ) => !prev) }}>Customize Settings</Button>
                      </BlockStack>
                    </Box>}
                  </InlineGrid>                  
                  
                </Collapsible>
              </BlockStack>
            </Card>
          ))}
        </BlockStack>
        
        {showSlidekick && <WidgetSettings setShowSlidekick={setShowSlidekick} />}
          
        </InlineGrid>        
      </Page>
    </>
  )
}


// // utils/format.ts
// export function capitalize(text: string): string {
//   if (!text) return '';
//   return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
// }