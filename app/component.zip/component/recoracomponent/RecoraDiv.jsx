import React from 'react'
const RecoraDiv = ({className ,  style , children}) => {
  return (
    <div className={`${className}`} style={style}>
        {children}
    </div>
  )
}
export default RecoraDiv
