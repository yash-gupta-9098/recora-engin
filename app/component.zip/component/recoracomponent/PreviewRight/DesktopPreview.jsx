import { Text } from '@shopify/polaris'
import React from 'react'
import "./CSS/DesktopPreview.css"
import { v4 as uuidv4 } from 'uuid';



export function DesktopPreview({products , previewStyle , payload}) {

  const uniqueKey = uuidv4();
  const rootCSS = {'--rcr-product-per-Dekview':payload.commanView.desktop.rangeDeskProValue ,
     '--rcr-product-image-size':payload.productImage.ratio , 
     '--rcr-product-title-size' : payload.productTitle.fontSize ,
      '--rcr-product-title-color': payload.productTitle.color
    }
  return (
    <ul className={`recoraRightPreview recora_preview_${previewStyle}`} style={rootCSS}>
                            {products.map((item) =>{
                                  const {id , title , media , variants , vendor} = item.node
                               return ( <li key={id} className='recora_Card' >
                                <div className='rcr-image-header'>
                                  <div className='rcr-image-container'>
                                  <div className={`rcr-image-wrapper ${payload.productImage.onHover ? "rcr-hover-mode": ""}`} >
                              {      media.nodes.map((item , index) => (
                                        <img key={index} className={`productImage recora_Image_${index}`} src={item?.preview?.image?.url} style={{objectFit: payload.productImage.cropImage ? "cover" : "contain" , objectPosition: `var(${payload.productImage.cropType}, center)`}}/>
                            ))}
                            </div>
                            </div>
                            </div>
                            {payload.productTitle.showTitle && (<h2 className={`rcr-product-title ${payload.productTitle.titleClip ? "rcr-truncate" : ""}` }  >{title}</h2>)}
                                    

                                </li>
                               )
    })}
                              </ul>
  )
}

export default DesktopPreview