import { BlockStack, Box, Button, ColorPicker, Divider, Grid, hsbToRgb, InlineGrid, InlineStack, Popover, rgbToHsb, Text, TextField } from '@shopify/polaris';
import { ChevronLeftIcon } from '@shopify/polaris-icons';
import React, { useEffect, useState } from 'react'
import { ColorPickerPopover } from './ColorPickerPopover';

export function ColorScheme({ colorScheme, setColorScheme, selectedColorSchemes, setSelectedColorSchemes }) {

    const schemeColors = selectedColorSchemes[colorScheme];
const {background,
    text,
    text_Secondary,
    shadow,
    primary_Outline_Button,
    secondary_Outline_Button,
    secondary_Button,
    secondary_Button_Label,
    primary_Button_Label,
    primary_Button} = schemeColors 

console.log(schemeColors, "schemeColors")
console.log(schemeColors.background, "schemeColors")

  


    return (
        <Box as="ul" style={{ maxHeight: "60vh", overflowY: "scroll", minHeight: "60vh" }} borderStyle="solid" printHidden={false} visuallyHidden={false} overflowY='scroll' minHeight='70vh' >
            <Box padding={300} >
                <BlockStack gap="300">
                    <InlineStack gap="200" blockAlign='center'>
                        <Button variant="tertiary" icon={ChevronLeftIcon} onClick={() => { setColorScheme(null) }}></Button>
                        <InlineGrid gap="200" >
                            <Text as="p" variant="bodyXs" fontWeight='bold' >Colors</Text>
                            <Text as="h3" variant="headingSm" fontWeight='bold'>Editing {colorScheme}</Text>
                        </InlineGrid>
                    </InlineStack>


                    <Grid>
                        <Grid.Cell columnSpan={{ "xs": 6, "sm": 6, "md": 4, "lg": 4, "xl": 4 }}>

                            <Box style={{ "display": "flex", "flexDirection": "column", background: `${background}`, border: `1px solid ${shadow}`, borderRadius: "var(--p-border-radius-100)", padding: "var(--p-space-200)" }} >
                                <InlineGrid gap="100" columns={2} alignItems='center'>
                                    <Text as="h3" variant="headingLg" fontWeight='bold' alignment="end"><p style={{color:`${text}`}}>A</p></Text>
                                    <Text as='h4' variant='headingLg' fontWeight='bold'><p style={{color:`${text_Secondary}`}} >a</p></Text>
                                    <Box style={{ padding: "2px", borderRadius: "var(--p-border-radius-100)", border: `1px solid ${primary_Outline_Button}`  , background:`${primary_Button}`}}></Box>
                                    <Box style={{ padding: "2px", borderRadius: "var(--p-border-radius-100)", border: `1px solid ${secondary_Outline_Button}`, background:`${secondary_Button}` }}></Box>

                                </InlineGrid>
                            </Box>


                        </Grid.Cell>
                        <Grid.Cell columnSpan={{ "xs": 6, "sm": 6, "md": 8, "lg": 8, "xl": 8 }}>

                            <Text as="p" variant="headingXs" >Editing this scheme's colors for widgets </Text>

                        </Grid.Cell>
                    </Grid>

                    <Divider ></Divider>


                    <BlockStack gap="400">



                        {Object.entries(schemeColors).map(([key, value]) => (
                            <ColorPickerPopover
                                key={key}
                                label={key}
                                colorValue={value}
                                onChange={(newColor) => {
                                    setSelectedColorSchemes((prev) => ({
                                        ...prev,
                                        [colorScheme]: {
                                            ...prev[colorScheme],
                                            [key]: newColor
                                        }
                                    }));
                                }}
                            />
                        ))}






                        {/* <Popover
                            active={toggleColor}
                            activator={<TextField
                                label="Color"
                                prefix={<Box as='span' style={{width:"20px" , height:"20px" , background:`${colorString}` ,  borderRadius:"50%" ,     display: "block"}}></Box>}
                                                                    minLength={3}
                                                                    maxLength={9}
                                                                    value={colorString}
                                                                    onFocus={buttonToggle}
                                                                    onChange={handleColor}
                                                                    onBlur={handleColor2}
                                                                    autoComplete="off"
                                                                />}
                            onClose={buttonToggle}
                        >
                            <Box padding={300}>
                            <ColorPicker onChange={setColor} color={color} allowAlpha />
                            </Box>
                        </Popover> */}


                    </BlockStack>
                </BlockStack>
            </Box>
        </Box>
    )
}

export default ColorScheme