import { Box, ColorPicker, hsbToRgb, Popover, rgbToHsb, TextField } from "@shopify/polaris";
import { set } from "mongoose";
import { useEffect, useState } from "react";

export function ColorPickerPopover({ label, colorValue, onChange }) {
    const [isOpen, setIsOpen] = useState(false);
    const [color, setColor] = useState(colorValue);
    const [contrastColor, setContrastColor] = useState();
    // const [colorString, setColorString] = useState(colorValue); 
  
    function rgbaToHex(r, g, b, a) {
        // Clamp the values to ensure they stay within the valid ranges.
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));
        a = Math.max(0, Math.min(1, a));

        // Convert RGBA values to their hex equivalents (2-digit format)
        const redHex = r.toString(16).padStart(2, '0');
        const greenHex = g.toString(16).padStart(2, '0');
        const blueHex = b.toString(16).padStart(2, '0');

        // Convert the alpha value (0 to 1) to hex (00 to FF)
        const alphaHex = Math.round(a * 255).toString(16).padStart(2, '0');

        // Return the hex string
        return `#${redHex}${greenHex}${blueHex}${alphaHex}`;
    }


    function hexToRgba(hex) {
        console.log(hex , "hex before")
        // Remove the '#' if it exists
        console.log(hex , "hex")
        hex = hex.replace(/^#/, '');
        console.log(hex, "hex")
        if (hex.length === 1) {
            hex = hex.split('').map(c => c + c + c).join('');
        }


        if (hex.length === 2) {
            hex = hex.split('').map(c => c + c + c).join('');
        }

        if (hex.length === 3) {
            hex = hex.split('').map(c => c + c).join('');
        }

        if (hex.length === 4) {
            hex = hex.split('').map(c => c + c).join('');
        }

        // If the hex string is 6 characters (RGB), add the default alpha FF (fully opaque)
        if (hex.length === 6) {
            hex += 'FF'; // Adding default alpha value
        }



        // Ensure the hex string is exactly 8 characters (RRGGBBAA)
        if (hex.length !== 8) {
            throw new Error('Invalid hex color format. Expected #RRGGBBAA');
        }

        // Extract the red, green, blue, and alpha values from the hex string
        const r = parseInt(hex.substring(0, 2), 16);
        const g = parseInt(hex.substring(2, 4), 16);
        const b = parseInt(hex.substring(4, 6), 16);
        const a = parseInt(hex.substring(6, 8), 16) / 255; // Convert alpha to a value between 0 and 1
        // console.log(red:r ,green:g ,  b, a)
        // Return the RGBA color object
        return { red: r, green: g, blue: b, alpha: a };
    }

    useEffect(() => {

    
        let rhextorgb = hexToRgba(color)
        
        console.log(rhextorgb , "rgbanewColor")
        setContrastColor(rgbToHsb(rhextorgb));

},[])


useEffect(() => {
  onChange(color)
},[color])


const  handleColor = (value) => {
    // console.log(value , "e.target.value")
    setColor(value)
    
}


const handleColor2 = (e) => {

    // const  rgbaToHextest  = hsbToRgb(value)
    // const valueTest =  rgbaToHex(rgbaToHextest.red, rgbaToHextest.green, rgbaToHextest.blue, rgbaToHextest.alpha)
// setColor(value);


let rhextorgb = hexToRgba(e.target.value)
        
        console.log(rhextorgb)
    //    const hsbValue =  setContrastColor(rgbToHsb(rhextorgb)); 
    setColor(rgbaToHex(rhextorgb.red, rhextorgb.green, rhextorgb.blue, rhextorgb.alpha))


//     const rgbaColor = hexToRgba(value);
//     const hsbColor = rgbToHsb(rgbaColor)
//     // let rhextorgb = hexToRgba(color)
// setContrastColor(hsbColor);
    // console.log(rhextorgb , "rgbanewColor")

    
        
    // // console.log(rhextorgb , "rgbanewColor")
    // setContrastColor(rgbToHsb(rhextorgb));


// setColor(value);

    // console.log(value , "e.target.value")
    // setColor(value)


    // try {
    //     const rgba = hexToRgba(value);
    //     setContrastColor(rgbToHsb(rgba));
    //   } catch (e) {
    //     console.warn("Invalid color input");
    //   }
    //     // let rhextorgb = value
    //     // console.log(rhextorgb , "rhextorgb")
    //     // console.log(rhextorgb)
    //     // setColor(rgbToHsb(rhextorgb));
    //     // setToggleColor(true)
    // setIsOpen(false)
    }






function  handleContrasColor (value) {
    console.log(value , "value")
    setContrastColor(value);
    const rgbaColor = hsbToRgb(value);
    const hexaColor = rgbaToHex(rgbaColor.red, rgbaColor.green, rgbaColor.blue, rgbaColor.alpha)
    setColor(hexaColor);
}

    // useEffect(() => {
    //         const rgbaColor = hexToRgba(colorValue);
    //         // console.log(rgbaColor, "rgbaColor")
    //         const hexaColor = (rgbaColor.red, rgbaColor.green, rgbaColor.blue, rgbaColor.alpha)
    //         //     const rgbaContrastColor = hsbToRgb(contrastColor);
    //         //     console.log(rgbaColor , "rgbaColor")
    //         //    const  hexacontrastColor = rgbaToHex(rgbaContrastColor.red , rgbaContrastColor.green , rgbaContrastColor.blue , rgbaContrastColor.alpha)
    //         console.log(hexaColor, "hexaColor")
            
    //         //  setContrastColorString(hexacontrastColor);
    //     }, [colorValue])

    // useEffect(() => {
    // //   const rgba = hexToRgba(color);
    // //   const hex = rgbaToHex(rgba.red, rgba.green, rgba.blue, rgba.alpha);
    // //   onChange(hex);
    // }, [color]);
  
    // useEffect(() => {
    //   setColor(colorValue); // Update internal state if parent value changes
    // }, [colorValue]);
  



    return (
      <Popover
        active={isOpen}
        activator={
          <TextField
            label={<div style={{textTransform:"capitalize"}}>{label.replace(/_/g, ' ')}</div>}
            prefix={
              <Box as='span' style={{
                width: "20px",
                height: "20px",
                background: color,
                borderRadius: "50%",
                display: "block"
              }}></Box>
            }
            value={color}
            onFocus={() => setIsOpen(true)}
            onChange={handleColor}
            onBlur={handleColor2}
          />
        }
        onClose={() => setIsOpen(false)}
      >
        <Box padding={300}>
          <ColorPicker color={contrastColor} onChange={handleContrasColor} allowAlpha />
        </Box>
      </Popover>
    );
  }
  